<?php

session_start(); // Continua la sesión existente 

require 'conexion.php'; // Conexión a la base de datos

// Verifica la sesión, si el usuario está autenticado si no redirige a login
if (!isset($_SESSION['usuario']) || empty($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Inicializa las variables para los mensajes
$mensaje = '';
$tipo_mensaje = '';
$errores = [];

// Carga los usuarios de la base de datos que serán responsables de los elementos y los guarda en la variable $usuarios
$query_usuarios = " SELECT id, CONCAT(nombres, ' ', apellidos) AS nombre_completo, rol
                    FROM usuarios
                    WHERE rol IN ('digitador', 'doctor')";
$result_usuarios = pg_query($conn, $query_usuarios);
$usuarios = pg_fetch_all($result_usuarios);

// Procesamiento del archivo CSV para carga automática
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES['csv_file'])) {
    $errores = [];
    $datos_validos = [];

    // Verifica si se ha subido un archivo de tipo CSV
    if (isset($_FILES['csv_file']['tmp_name']) && is_uploaded_file($_FILES['csv_file']['tmp_name'])) {
        $archivo = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($archivo, 'r');
        $linea = 0;
        $primera_linea = fgets($handle); // Leer la primera línea del archivo CSV y determina el delimitador 
        $cantidad_tabs = substr_count($primera_linea, "\t"); // Detecta si la línea tiene más tabulaciones  
        $cantidad_comas = substr_count($primera_linea, ","); // Detecta si la línea tiene comas 

        if ($cantidad_tabs > $cantidad_comas) {
            $delimitador = "\t"; // Si hay más tabulaciones, se asume que ese es el delimitador
        } else {
            $delimitador = ","; // En caso contrario, se asume delimitador tipo CSV 
        }
        rewind($handle);

        while (($data = fgetcsv($handle, 1000, $delimitador)) !== FALSE) { // Lee cada línea del archivo CSV
            $linea++;
            if (count($data) < 6) {
                $errores[] = "Línea $linea: Número de columnas insuficiente";
                continue;
            }

            $data = array_map(function ($campo) {
                $campo = trim($campo); // Eliminar espacios y caracteres no imprimibles

                // Asegura la codificación UTF-8 válida 
                if (!mb_check_encoding($campo, 'UTF-8')) {
                    $campo = mb_convert_encoding($campo, 'UTF-8');
                }

                $campo = preg_replace('/[[:^print:]]/', '', $campo); // Elimina caracteres no imprimibles
                return $campo;
            }, $data);
            list($marca, $modelo, $serial, $categoria, $estado, $id_usuario) = $data; // Envia los datos a las variables en un arreglo

            // Validación de formato para cada campo del registro, rechazando entradas mal formateadas o inválidas
            if (!preg_match('/^[\p{L}0-9\s\.\-]{2,50}$/u', $marca)) {
                $errores[] = "Línea $linea: Marca inválida (solo letras, números, espacios, guiones, diéresis, puntos y acentuación)";
                continue;
            }
            if (!preg_match('/^[\p{L}0-9\s\.\-]{2,50}$/u', $modelo)) {
                $errores[] = "Línea $linea: Modelo inválido (solo letras, números, espacios, guiones, diéresis, puntos y acentuación)";
                continue;
            }
            if (!preg_match('/^[A-Za-z0-9\-]{4,30}$/', $serial)) {
                $errores[] = "Línea $linea: Número de serie inválido (letras, números y guiones, 4-30 caracteres)";
                continue;
            }
            if (!preg_match('/^[\p{L}\s]{3,30}$/u', $categoria)) {
                $errores[] = "Línea $linea: Categoría inválida (solo letras con acento y espacios)";
                continue;
            }
            if (!preg_match('/^[\p{L}\s]{3,30}$/u', $estado)) {
                $errores[] = "Línea $linea: Estado inválido (solo letras con acento y espacios)";
                continue;
            }
            if (!preg_match('/^\d+$/', $id_usuario)) {
                $errores[] = "Línea $linea: ID de usuario inválido";
                continue;
            }

            // Busca el usuario por su id y si no existe, registra error y omite el registro
            $usuario_encontrado = array_filter($usuarios, fn($u) => $u['id'] == $id_usuario);
            if (empty($usuario_encontrado)) {
                $errores[] = "Línea $linea: Usuario con ID $id_usuario no encontrado";
                continue;
            }

            // Extrae datos del usuario responsable y los agrega con los campos validados a un arreglo intermedio
            $usuario_datos = reset($usuario_encontrado);
            $usuario_responsable = $usuario_datos['nombre_completo'];
            $rol_responsable = $usuario_datos['rol'];

            // Almacena en arreglo intermedio
            $datos_validos[] = [$marca, $modelo, $serial, $categoria, $estado, $id_usuario, $usuario_responsable, $rol_responsable];
        }
        fclose($handle);

        // Verifica si hay errores antes de insertar
        if (!empty($errores)) {
            $mensaje = "Se encontraron errores en el archivo CSV:<br><strong>" . implode("<br>", $errores) . "</strong><br><br>Corrija el archivo completo y vuelva a cargarlo.";
            $tipo_mensaje = "error";
        } else {
            // Se prepara la consulta SQL para insertar el nuevo registro en la base de datos con parametros preparados
            foreach ($datos_validos as $params) {
                $query_insert = "INSERT INTO inventario (marca, modelo, serial, categoria, estado, id_usuario, usuario_responsable, rol_responsable) 
                                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";
                $resultado = pg_query_params($conn, $query_insert, $params);

                // Verifica si llega a existir un error en la inserción a la base de datos especialmente el serial que no puede ser duplicado
                if ($resultado === false) {
                    $error_pg = pg_last_error($conn);
                    if (strpos($error_pg, 'llave duplicada') !== false) {
                        $errores[] = "El serial '{$params[2]}' ya existe en la base de datos";
                    } else {
                        $errores[] = "Error al insertar el serial '{$params[2]}': $error_pg";
                    }
                }
            }

            // Si existe mas de un error, se muestra el mensaje de error y no sube el archivo, de lo contrario muestra el mensaje de éxito
            if (!empty($errores)) {
                $mensaje = "No se pudo completar la operación. Se detectaron errores en la inserción:<br><strong>" . implode("<br>", $errores) . "</strong>";
                $tipo_mensaje = "error";
            } else {
                $mensaje = "Todos los elementos fueron agregados exitosamente al inventario";
                $tipo_mensaje = "success";
            }
        }
    } else {  // Si no se subió un archivo válido muestra un mensaje de error
        $mensaje = "No se ha subido ningún archivo válido";
        $tipo_mensaje = "error";
    }
}

// Procesamiento de formulario manual y se envia por metodo POST
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['marca'])) {

    // Captura de los datos y si no existen se asigna un valor vacío
    if (isset($_POST['marca'])) {
        $marca = trim($_POST['marca']);
    } else {
        $marca = '';
    }
    if (isset($_POST['modelo'])) {
        $modelo = trim($_POST['modelo']);
    } else {
        $modelo = '';
    }
    if (isset($_POST['serial'])) {
        $serial = trim($_POST['serial']);
    } else {
        $serial = '';
    }
    if (isset($_POST['categoria'])) {
        $categoria = trim($_POST['categoria']);
    } else {
        $categoria = '';
    }
    if (isset($_POST['estado'])) {
        $estado = trim($_POST['estado']);
    } else {
        $estado = '';
    }
    if (isset($_POST['id_usuario'])) {
        $id_usuario = trim($_POST['id_usuario']);
    } else {
        $id_usuario = '';
    }

    // Validación de formato para cada campo del registro, rechazando entradas mal formateadas o inválidas
    if (!preg_match('/^[A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\s\-_]{2,50}$/', $marca)) {
        $errores[] = "Marca inválida (solo letras, números, espacios, guiones)";
    }

    if (!preg_match('/^[A-Za-z0-9ÁÉÍÓÚÑáéíóúñ\s\-_]{2,50}$/', $modelo)) {
        $errores[] = "Modelo inválido (solo letras, números, espacios, guiones)";
    }

    if (!preg_match('/^[A-Za-z0-9\-]{4,30}$/', $serial)) {
        $errores[] = "Número de serie inválido (letras, números y guiones, 4-30 caracteres)";
    }

    if (!preg_match('/^[A-Za-zÁÉÍÓÚÑáéíóúñ\s]{3,30}$/', $categoria)) {
        $errores[] = "Categoría inválida (solo letras y espacios)";
    }

    if (!preg_match('/^[A-Za-zÁÉÍÓÚÑáéíóúñ\s]{3,30}$/', $estado)) {
        $errores[] = "Estado inválido (solo letras y espacios)";
    }

    if (!preg_match('/^\d+$/', $id_usuario)) {
        $errores[] = "ID de usuario inválido";
    }

    // Si no hay errores, continua con búsqueda del usuario responsable
    if (empty($errores)) {
        $usuario_encontrado = array_filter($usuarios, fn($u) => $u['id'] == $id_usuario); // Busca el usuario responsable por su id 
        if (empty($usuario_encontrado)) {
            $mensaje = "El usuario seleccionado no existe en la base de datos"; // Si no existe el usuario, se muestra un mensaje de error
            $tipo_mensaje = "error";
        } else {
            $usuario_datos = reset($usuario_encontrado); // Si existe el usuario, se obtiene su información nombre y rol
            $usuario_responsable = $usuario_datos['nombre_completo'];
            $rol_responsable = $usuario_datos['rol'];

            // Se prepara la consulta SQL para insertar el nuevo registro en la base de datos con parametros preparados
            $query_insert = "INSERT INTO inventario (marca, modelo, serial, categoria, estado, id_usuario, usuario_responsable, rol_responsable) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";
            $params = [$marca, $modelo, $serial, $categoria, $estado, $id_usuario, $usuario_responsable, $rol_responsable];
            $result = pg_query_params($conn, $query_insert, $params);

            // Verifica si la inserción fue exitosa
            if ($result) {
                $mensaje = "Elemento agregado al inventario correctamente";
                $tipo_mensaje = "success";
            } else {
                $mensaje = "Error al registrar el elemento en el inventario";
                $tipo_mensaje = "error";
            }
        }
    } else {
        $mensaje = implode("<br>", $errores); // Si hay errores, se muestran todos en conjunto
        $tipo_mensaje = "error";
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTRAR EN INVENTARIO</title>
    <link rel="stylesheet" href="estilos/regInventario.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>

<body>

    <header>
        <a href="digitador.php">
            <img src="imágenes/volver.png" alt="Volver" class="btn-volver">
        </a>

        <?php if ($mensaje): ?>
            <p class="alerta <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la lógica -->
        <?php endif; ?>

        <a href="verInventario.php" class="btn-envio btn-ver-inventario">VER INVENTARIO</a>
    </header>

    <div class="container">
        <div class="left-container">
            <h1>REGISTRAR EN EL INVENTARIO</h1>
        </div>

        <div class="right-container">
            <?php if (!isset($_POST['accion'])): ?> <!-- Si no se ha enviado el formulario, muestra las opciones de carga -->
                <form method="POST">
                    <div class="form-row">
                        <input type="submit" name="accion" value="CARGA POR CSV" class="btn-envio btn-csv">
                        <input type="submit" name="accion" value="REGISTRO MANUAL" class="btn-envio btn-manual">
                    </div>
                </form>
            <?php endif; ?>

            <!-- Formulario CSV -->
            <?php if (isset($_POST['accion']) && $_POST['accion'] === 'CARGA POR CSV'): ?> <!-- Si se selecciona la carga por CSV, mostrar el formulario para cargar el archivo -->
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-row">
                        <label><strong>CARGA AUTOMÁTICA DESDE ARCHIVO CSV</strong></label>
                        <input type="file" name="csv_file" accept=".csv" required lang="es">
                    </div>
                    <div class="row-submit">
                        <input type="submit" value="CARGAR CSV" class="btn-envio btn-registro">
                    </div>
                </form>
            <?php endif; ?>

            <?php if (isset($_POST['accion']) && $_POST['accion'] == 'REGISTRO MANUAL'): ?> <!-- Si se selecciona el registro manual, mostrar el formulario para ingresar los datos -->
                <form method="POST">
                    <div class="form-row">
                        <div class="form-column">
                            <label for="marca">MARCA:</label>
                            <input type="text" name="marca" id="marca" required placeholder="Solo letras, números, guiones o espacios" value="<?php if (isset($marca)) echo htmlspecialchars($marca); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                        <div class="form-column">
                            <label for="modelo">MODELO:</label>
                            <input type="text" name="modelo" id="modelo" required placeholder="Solo letras, números, guiones o espacios" value="<?php if (isset($modelo)) echo htmlspecialchars($modelo); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="serial">SERIAL:</label>
                            <input type="text" name="serial" id="serial" required placeholder="Solo letras, números o guiones" value="<?php if (isset($serial)) echo htmlspecialchars($serial); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                        <div class="form-column">
                            <label for="categoria">CATEGORÍA:</label>
                            <input type="text" name="categoria" id="categoria" required placeholder="Solo letras, acentos y espacios" value="<?php if (isset($categoria)) echo htmlspecialchars($categoria); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="estado">ESTADO:</label>
                            <input type="text" name="estado" id="estado" required placeholder="Solo letras, acentos y espacios" value="<?php if (isset($estado)) echo htmlspecialchars($estado); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                        <div class="form-column">
                            <label for="id_usuario">PERSONA RESPONSABLE:</label>
                            <select name="id_usuario" id="id_usuario" required>
                                <option value="" disabled selected>Seleccione una persona</option>
                                <?php foreach ($usuarios as $usuario): ?> <!-- Se itera sobre los usuarios y se crea una opción para cada uno -->
                                    <option value="<?php echo $usuario['id']; ?>" <?php if (isset($id_usuario) && $id_usuario == $usuario['id']) echo 'selected'; ?>> <!-- Se selecciona el usuario si ya fue elegido -->
                                        <?php echo htmlspecialchars($usuario['nombre_completo']); ?> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row-submit">
                        <input type="submit" value="REGISTRAR" class="btn-envio btn-registro">
                    </div>
                </form>
            <?php endif; ?>


        </div>
    </div>

</body>

</html>