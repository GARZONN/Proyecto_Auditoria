<?php

session_start(); // Continua la sesión existente 


require 'conexion.php'; // Conexión a la base de datos

$mensaje = '';
$tipo_mensaje = '';

// Consulta del inventario
$sql = "SELECT marca, modelo, serial, categoria, estado, usuario_responsable, rol_responsable FROM inventario ORDER BY id_inventario DESC";
$resultado = pg_query($conn, $sql);

// Validación de errores en la consulta
if (!$resultado) {
    die("Error al ejecutar la consulta: " . pg_last_error($conn));
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VER INVENTARIO</title>
    <link rel="stylesheet" href="estilos/verInventario.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>
<body>

<header>
    <a href="regInventario.php"><img src="imágenes/volver.png" alt="Volver" class="btn-volver"></a>

    <?php if ($mensaje): ?>
        <p class="alerta <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la lógica -->
    <?php endif; ?>
</header>

<div class="container">
    <div class="left-container">
        <h1>VER INVENTARIO</h1>
    </div>

    <div class="right-container">
        <?php if ($resultado && pg_num_rows($resultado) > 0): ?> <!-- Verifica si hay resultados en la consulta -->
            <div class="tabla-contenedor">  
                <table class="tabla-inventario">
                    <thead>
                        <tr>
                            <th>N°</th> 
                            <th>MARCA</th>
                            <th>MODELO</th>
                            <th>SERIAL</th>
                            <th>CATEGORÍA</th>
                            <th>ESTADO</th>
                            <th>RESPONSABLE</th>
                            <th>ROL</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $contador = 1; // Inicia el contador en 1
                        while ($fila = pg_fetch_assoc($resultado)): ?> <!-- Recorre los resultados de la consulta -->
                            <tr>
                                <td><?php echo $contador++; ?></td> <!-- Incrementa el contador por cada fila -->
                                <td><?php echo htmlspecialchars($fila['marca']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                <td><?php echo htmlspecialchars($fila['modelo']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                <td><?php echo htmlspecialchars($fila['serial']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                <td><?php echo htmlspecialchars($fila['categoria']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                <td><?php echo htmlspecialchars($fila['estado']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                <td><?php echo htmlspecialchars($fila['usuario_responsable']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                <td><?php echo htmlspecialchars($fila['rol_responsable']); ?></td> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="alerta error">No hay registros en el inventario</p>
        <?php endif; ?>
    </div>
</div>

</body>
</html>
