<?php

session_start(); // Continua la sesión existente 

require 'conexion.php'; // Conexión a la base de datos

$mensaje = ''; // Inicializa la variable para los mensajes 

// Verifica si existe un superusuario en la base de datos
$mostrar_boton_registro = false;
if ($conn) {
    $query_superusuario = "SELECT 1 FROM usuarios WHERE rol = 'superusuario' LIMIT 1";
    $resultado_superusuario = pg_query($conn, $query_superusuario);
    if ($resultado_superusuario && pg_num_rows($resultado_superusuario) === 0) {
        $mostrar_boton_registro = true;
    }
}

// Captura las credenciales del formulario a través de POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $usuario = trim($_POST['usuario']);
    $password = $_POST['password'];

    // Validación de caracteres permitidos en el usuario y el correo
    if (!ctype_alnum(str_replace(['@', '.', '_'], '', $usuario))) {
        $mensaje = "El usuario o correo contiene caracteres inválidos.";
    }
    // Verifica si la conexión con la base de datos está activa
    elseif ($conn) {
        // Consulta preparada para buscar al usuario por nombre o correo
        $query = "SELECT id, usuario, correo, password, rol, genero FROM usuarios WHERE (usuario = $1 OR correo = $1) LIMIT 1";
        $result = pg_query_params($conn, $query, array($usuario));

        // Verifica si se obtuvo un resultado
        if ($result && pg_num_rows($result) > 0) {
            $row = pg_fetch_assoc($result);

            // Verifica que la contraseña ingresada coincida con la almacenada 
            if (password_verify($password, $row['password'])) {
                session_regenerate_id(true); // / Regenera el id de sesión para prevenir secuestro de sesión

                // Guarda datos esenciales del usuario en la sesión
                $_SESSION['usuario'] = $row['usuario'];
                $_SESSION['rol']     = $row['rol'];
                $_SESSION['genero']  = $row['genero'];

                // Redirige al usuario según su rol
                switch ($row['rol']) {
                    case 'superusuario':
                        header("Location: index.php");
                        exit;
                    case 'digitador':
                        header("Location: digitador.php");
                        exit;
                    case 'paciente':
                        header("Location: paciente.php");
                        exit;
                    default:
                        $mensaje = "Usuario no encontrado.";
                        break;
                }
            } else {
                $mensaje = "Usuario o contraseña incorrectos.";
            }
        } else {
            $mensaje = "Usuario o contraseña incorrectos.";
        }

        // Cierra la conexión con la base de datos
        pg_close($conn);
    } else {
        error_log("Error de conexión con la base de datos."); // Error en la conexión a la base de datos
        die("Servicio no disponible.");
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="estilos/login.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>

<body>

    <header>
        <div class="header-contenedor">
            <?php if ($mostrar_boton_registro): ?>
                <a href="priRegistro.php" class="panel-button">PRIMER REGISTRO</a> <!-- Botón para el primer registro solo aparecerá si en la base de datos no hay ningún usuario de rol superusuario -->
            <?php endif; ?>

            <?php if (!empty($mensaje)): ?>
                <div class="mensaje-error">
                    <p><?php echo htmlspecialchars($mensaje); ?></p> <!-- Muestra el mensaje de éxito o error según lo que pase en la lógica -->
                </div>
            <?php endif; ?>
        </div>
    </header>

    <section class="titulo">
        <h2>Plataforma de Registro Inicial para Atención en Salud</h2>
    </section>

    <div class="container">
        <div class="form-container">
            <h2>INICIAR SESIÓN</h2>
            <form method="POST">
                <div class="row">
                    <label for="usuario">USUARIO <br> O <br> CORREO:</label>
                    <input type="text" name="usuario" id="usuario" required placeholder="Proporcione su usuario o correo" value="<?php echo isset($usuario) ? htmlspecialchars($usuario) : ''; ?>">
                </div>
                <div class="row">
                    <label for="password">CONTRASEÑA:</label>
                    <input type="password" name="password" id="password" required placeholder="Proporcione su contraseña" value="">
                </div>
                <div class="row-submit">
                    <input type="submit" value="INGRESAR">
                </div>
            </form>

        </div>
    </div>

</body>

</html>