<?php

session_start(); // Continua la sesión existente 

require 'conexion.php'; // Conexión a la base de datos

// Inicializa las variables para los mensajes
$mensaje = '';
$tipo_mensaje = '';
$errores = [];

// Procesamiento de formulario y se envia por metodo POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Captura de datos del formulario y si no existe se asigna un valor por defecto
    if (isset($_POST['nombres'])) {
        $nombres = $_POST['nombres'];
    } else {
        $nombres = '';
    }
    if (isset($_POST['apellidos'])) {
        $apellidos = $_POST['apellidos'];
    } else {
        $apellidos = '';
    }
    if (isset($_POST['genero'])) {
        $genero = $_POST['genero'];
    } else {
        $genero = '';
    }
    if (isset($_POST['correo'])) {
        $correo = $_POST['correo'];
    } else {
        $correo = '';
    }
    if (isset($_POST['password'])) {
        $password = $_POST['password'];
    } else {
        $password = '';
    }
    if (isset($_POST['confirmar_password'])) {
        $confirmar_password = $_POST['confirmar_password'];
    } else {
        $confirmar_password = '';
    }
    if (isset($_POST['usuario'])) {
        $usuario = $_POST['usuario'];
    } else {
        $usuario = '';
    }
    if (isset($_POST['num_doc'])) {
        $num_doc = $_POST['num_doc'];
    } else {
        $num_doc = '';
    }
    if (isset($_POST['telefono'])) {
        $telefono = $_POST['telefono'];
    } else {
        $telefono = '';
    }
    if (isset($_POST['direccion'])) {
        $direccion = $_POST['direccion'];
    } else {
        $direccion = '';
    }

    // Variables fijas
    $rol = 'superusuario';
    $tipo_doc = 'CC';

    // // Validación de formato para cada campo del registro, rechazando entradas mal formateadas o inválidas
    if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]{2,50}$/', $nombres)) {
        $errores[] = "Nombre inválido.";
    }
    if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]{2,50}$/', $apellidos)) {
        $errores[] = "Apellido inválido.";
    }
    if (!in_array($genero, ['masculino', 'femenino'])) {
        $errores[] = "Género inválido.";
    }
    if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "Correo inválido.";
    }
    if (strlen($password) < 12 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/\d/', $password) || !preg_match('/[\W_]/', $password)) {
        $errores[] = "Contraseña insegura.";
    }
    if ($password !== $confirmar_password) {
        $errores[] = "Las contraseñas no coinciden.";
    }
    if (!preg_match('/^[A-Za-z0-9]{4,10}$/', $usuario)) {
        $errores[] = "Usuario inválido.";
    }
    if (!preg_match('/^\d{6,15}$/', $num_doc)) {
        $errores[] = "Número de documento inválido.";
    }
    if (!preg_match('/^\d{10}$/', $telefono)) {
        $errores[] = "Teléfono inválido.";
    }
    if (strlen($direccion) < 5 || strlen($direccion) > 20) {
        $errores[] = "Dirección inválida.";
    }

    //  // Si no hay errores, se prepara la consulta SQL para actualizar el ususario en la base de datos con parametros preparados
    if (empty($errores)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $query_insert = "INSERT INTO usuarios (nombres, apellidos, genero, correo, password, usuario, rol, tipo_doc, num_doc, telefono, direccion)
                        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)";
        $params = [$nombres, $apellidos, $genero, $correo, $hashed_password, $usuario, $rol, $tipo_doc, $num_doc, $telefono, $direccion];

        $result = pg_query_params($conn, $query_insert, $params);

        // Verifica si la consulta se ejecutó correctamente
        if ($result) {
            header("Location: login.php");
            exit();
        } else {
            $mensaje = "Error al registrar el usuario.";
            $tipo_mensaje = "error";
        }
    } else {
        $mensaje = implode("<br>", $errores);
        $tipo_mensaje = "error";
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar SUPERUSUARIO</title>
    <link rel="stylesheet" href="estilos/regPersona.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>

<body>

    <header>
        <a href="login.php"><img src="imágenes/volver.png" alt="Volver" class="btn-volver"></a>

        <?php if ($mensaje): ?>
            <p class="alerta <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la lógica -->
        <?php endif; ?>
    </header>

    <div class="container">
        <div class="left-container">
            <h1>REGISTRAR SUPERUSUARIO</h1>
        </div>

        <div class="right-container">
            <form method="POST" novalidate>

                <div class="form-row">
                    <div class="form-column">
                        <label for="nombres">NOMBRE(S):</label>
                        <input type="text" name="nombres" id="nombres" required placeholder="Solo letras, acentos, ñ y espacios" value="<?php if (isset($nombres)) echo htmlspecialchars($nombres); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                    <div class="form-column">
                        <label for="apellidos">APELLIDOS:</label>
                        <input type="text" name="apellidos" id="apellidos" required placeholder="Solo letras, acentos, ñ y espacios" value="<?php if (isset($apellidos)) echo htmlspecialchars($apellidos); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="genero">GÉNERO:</label>
                        <select name="genero" id="genero" required>
                            <option value="" disabled <?php if (!isset($rol)) echo 'selected'; ?>>Seleccione su género</option>
                            <option value="masculino" <?php if (isset($genero) && $genero == 'masculino') echo 'selected'; ?>>Masculino</option>
                            <option value="femenino" <?php if (isset($genero) && $genero == 'femenino') echo 'selected'; ?>>Femenino</option>
                        </select>
                    </div>
                    <div class="form-column">
                        <label for="correo">CORREO:</label>
                        <input type="email" name="correo" id="correo" required placeholder="Ej: nombre@dominio.com" value="<?php if (isset($correo)) echo htmlspecialchars($correo); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="password">CONTRASEÑA:</label>
                        <input type="password" name="password" id="password" required placeholder="Mínimo 12 mayús minús número símbolo" value="">
                    </div>
                    <div class="form-column">
                        <label for="confirmar_password">CONFIRMAR CONTRASEÑA:</label>
                        <input type="password" name="confirmar_password" id="confirmar_password" required placeholder="Repetir contraseña" value="">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="usuario">USUARIO:</label>
                        <input type="text" name="usuario" id="usuario" required placeholder="Entre 4 y 10 letras o números sin espacios ni símbolos" value="<?php if (isset($usuario)) echo htmlspecialchars($usuario); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                    <div class="form-column">
                        <label for="rol">ROL:</label>
                        <input type="text" id="rol" value="Superusuario" disabled>
                        <input type="hidden" name="rol" value="superusuario">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="tipo_doc">TIPO DE DOCUMENTO:</label>
                        <input type="text" id="tipo_doc" value="CC" disabled>
                        <input type="hidden" name="tipo_doc" value="CC">
                    </div>
                    <div class="form-column">
                        <label for="num_doc">N° DE DOCUMENTO:</label>
                        <input type="text" name="num_doc" id="num_doc" required placeholder="Solo números mínimo 6 máximo 15" value="<?php if (isset($num_doc)) echo htmlspecialchars($num_doc); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="telefono">TELÉFONO:</label>
                        <input type="text" name="telefono" id="telefono" required placeholder="Solo 10 números sin espacios ni símbolos" value="<?php if (isset($telefono)) echo htmlspecialchars($telefono); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                    <div class="form-column">
                        <label for="direccion">DIRECCIÓN:</label>
                        <input type="text" name="direccion" id="direccion" required placeholder="Entre 5 a 20 letras, números, (.) (#) (-)" value="<?php if (isset($direccion)) echo htmlspecialchars($direccion); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                    </div>
                </div>

                <div class="row-submit">
                    <input type="submit" value="REGISTRAR">
                </div>
            </form>
        </div>
    </div>

</body>

</html>