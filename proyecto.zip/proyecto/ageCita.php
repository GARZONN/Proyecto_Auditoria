<?php

session_start(); // Continua la sesión existente 

require 'conexion.php'; // Conexión a la base de datos

// // Verifica la sesión, si el usuario está autenticado si no redirige a login
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Inicializa las variables para los mensajes y los datos
$mensaje = '';
$tipo_mensaje = '';
$paciente_encontrado = false;
$datos_paciente = [];
$lista_medicos = [];
$errores = [];


// Carga los ussuarios de la base de datos que son médicos
$query_medicos = "SELECT id, nombres, apellidos FROM usuarios WHERE rol = 'doctor'";
$result_medicos = pg_query($conn, $query_medicos);
if ($result_medicos && pg_num_rows($result_medicos) > 0) {
    while ($medico = pg_fetch_assoc($result_medicos)) {
        $lista_medicos[] = $medico;
    }
}

// Procesamiento de formulario y se envia por el método POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Validación de la búsqueda de paciente con una consulta parametrizada
    if (isset($_POST['buscar_paciente'])) {
        $num_doc = trim($_POST['num_doc']);
        if (preg_match('/^\d{6,15}$/', $num_doc)) {
            $query_buscar = "SELECT id, nombres, apellidos, num_doc FROM usuarios WHERE num_doc = $1 AND rol = 'paciente' LIMIT 1";
            $result_buscar = pg_query_params($conn, $query_buscar, [$num_doc]);
            if ($result_buscar && pg_num_rows($result_buscar) > 0) {
                $datos_paciente = pg_fetch_assoc($result_buscar);
                $paciente_encontrado = true;
            } else {
                $errores[] = "Paciente no encontrado.";
            }
        } else {
            $errores[] = "El número de documento no es válido.";
        }
    }

    // Validación y agendamiento de cita
    if (isset($_POST['agendar_cita'])) {

        // Captura de datos del formulario y si no existe se asigna un valor por defecto
        if (isset($_POST['id_usuario'])) {
            $id_usuario = intval($_POST['id_usuario']);
        } else {
            $id_usuario = null;
        }
        if (isset($_POST['nombre_paciente'])) {
            $nombre_paciente = trim($_POST['nombre_paciente']);
        } else {
            $nombre_paciente = '';
        }
        if (isset($_POST['fecha_cita'])) {
            $fecha_cita = trim($_POST['fecha_cita']);
        } else {
            $fecha_cita = '';
        }
        if (isset($_POST['hora_cita'])) {
            $hora_cita = trim($_POST['hora_cita']);
        } else {
            $hora_cita = '';
        }
        if (isset($_POST['tipo_consulta'])) {
            $tipo_consulta = trim($_POST['tipo_consulta']);
        } else {
            $tipo_consulta = '';
        }
        if (isset($_POST['motivo'])) {
            $motivo = trim($_POST['motivo']);
        } else {
            $motivo = '';
        }
        if (isset($_POST['medico_asignado'])) {
            $medico_asignado_nombre = trim($_POST['medico_asignado']);
        } else {
            $medico_asignado_nombre = '';
        }


        // Validación de formato para cada campo del registro, rechazando entradas mal formateadas o inválidas
        if (empty($id_usuario) || !is_numeric($id_usuario)) {
            $errores[] = "ID de paciente inválido.";
        }

        if (empty($nombre_paciente)) {
            $errores[] = "El nombre del paciente es obligatorio.";
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $fecha_cita)) {
            $errores[] = "La fecha de la cita no tiene el formato válido (YYYY-MM-DD).";
        }

        if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $hora_cita)) {
            $errores[] = "La hora de la cita no tiene el formato válido (HH:MM).";
        }

        if (empty($tipo_consulta)) {
            $errores[] = "El tipo de consulta es obligatorio.";
        }

        if (empty($motivo)) {
            $errores[] = "El motivo de la consulta es obligatorio.";
        }

        if (empty($medico_asignado_nombre)) {
            $errores[] = "Debe seleccionar un médico asignado.";
        }

        // Si no hay errores, continua con la busqueda del médico asignado
        if (empty($errores)) {   // Obtener el id y el nombre del médico asignado
            $query_medico_id = "SELECT id, nombres, apellidos FROM usuarios WHERE nombres || ' ' || apellidos = $1 AND rol = 'doctor' LIMIT 1";
            $result_medico_id = pg_query_params($conn, $query_medico_id, [$medico_asignado_nombre]);
            if ($result_medico_id && pg_num_rows($result_medico_id) > 0) {
                $medico_data = pg_fetch_assoc($result_medico_id);
                $medico_asignado = $medico_data['id'];
                $nombre_doctor = $medico_data['nombres'] . ' ' . $medico_data['apellidos'];

                // // Se prepara la consulta SQL para insertar el nuevo registro en la base de datos con parametros preparados
                $query_insert = "INSERT INTO citas (id_usuario, fecha_cita, hora_cita, tipo_consulta, motivo, id_doctor, nombre_doctor, nombre_paciente)
                                VALUES ($1, $2, $3, $4, $5, $6, $7, $8)";
                $params = [$id_usuario, $fecha_cita, $hora_cita, $tipo_consulta, $motivo, $medico_asignado, $nombre_doctor, $nombre_paciente];
                $result_insert = pg_query_params($conn, $query_insert, $params);

                // Verifica si la inserción fue exitosa
                if ($result_insert) {
                    $mensaje = "Cita agendada exitosamente.";
                    $tipo_mensaje = "success";
                } else {
                    $mensaje = "Error al agendar la cita: " . pg_last_error($conn);
                    $tipo_mensaje = "error";
                }
            } else {
                $errores[] = "Médico asignado no encontrado.";
            }
        } else {
            $mensaje = implode("<br>", $errores); // Si hay errores, se muestra en conjunto
            $tipo_mensaje = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar Cita</title>
    <link rel="stylesheet" href="estilos/ageCita.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>

<body>

    <header>
        <a href="digitador.php">
            <img src="imágenes/volver.png" alt="Volver" class="btn-volver">
        </a>

        <?php if ($mensaje) { ?>
            <p class="alerta <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la logica -->
        <?php } ?>
    </header>

    <div class="container">
        <div class="left-container">
            <h1>AGENDAR CITA</h1>
        </div>

        <div class="right-container">

            <?php if (!$paciente_encontrado) { ?> <!-- Si no se ha encontrado el paciente, muestra el formulario de búsqueda -->
                <form method="POST">
                    <div class="form-row">
                        <div class="form-column" style="width: 100%;">
                            <label for="num_doc">N° DE DOCUMENTO DEL PACIENTE:</label>
                            <input type="text" name="num_doc" id="num_doc" required placeholder="Número de documento">
                        </div>
                    </div>
                    <div class="row-submit">
                        <input type="submit" name="buscar_paciente" value="BUSCAR PACIENTE" class="btn-buscar">
                    </div>
                </form>
            <?php } ?>

            <?php if ($paciente_encontrado) { ?><!-- Si se ha encontrado el paciente, muestra el formulario para agendar la cita -->
                <form method="POST">
                    <input type="hidden" name="id_usuario" value="<?php echo $datos_paciente['id']; ?>"> <!-- Se oculta el id del paciente para no mostrarlo en el formulario -->

                    <div class="form-row">
                        <div class="form-column" style="width: 100%;">
                            <label for="nombre_paciente">NOMBRE DEL PACIENTE:</label>
                            <input type="text" id="nombre_paciente_visible" value="<?php echo $datos_paciente['nombres'] . ' ' . $datos_paciente['apellidos']; ?>" readonly> <!-- Se muestra el nombre completo del paciente -->
                            <input type="hidden" name="nombre_paciente" value="<?php echo $datos_paciente['nombres'] . ' ' . $datos_paciente['apellidos']; ?>"> <!-- Se oculta el nombre completo para enviarlo al formulario -->
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="fecha_cita">FECHA DE LA CITA:</label>
                            <input type="date" name="fecha_cita" id="fecha_cita" required>
                        </div>
                        <div class="form-column">
                            <label for="hora_cita">HORA DE LA CITA:</label>
                            <input type="time" name="hora_cita" id="hora_cita" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="tipo_consulta">TIPO DE CONSULTA:</label>
                            <input type="text" name="tipo_consulta" id="tipo_consulta" required placeholder="Solo letras, acentos, espacios y sin símbolos.">
                        </div>
                        <div class="form-column">
                            <label for="medico_asignado">MÉDICO ASIGNADO:</label>
                            <select name="medico_asignado" id="medico_asignado" required>
                                <option value="" disabled selected>Seleccione un médico</option>
                                <?php foreach ($lista_medicos as $medico): ?> <!-- Se recorre la lista de médicos y se muestra en el select -->
                                    <option value="<?php echo htmlspecialchars($medico['nombres'] . ' ' . $medico['apellidos']); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                        <?php echo htmlspecialchars($medico['nombres'] . ' ' . $medico['apellidos']); ?> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column" style="width: 100%;">
                            <label for="motivo">MOTIVO DE LA CITA:</label>
                            <textarea name="motivo" id="motivo" required placeholder="Solo letras, acentos, espacios y sin símbolos."></textarea>
                        </div>
                    </div>

                    <div class="row-submit">
                        <input type="submit" name="agendar_cita" value="AGENDAR CITA" class="btn-agendar">
                    </div>
                </form>
            <?php } ?>

        </div>
    </div>

</body>

</html>