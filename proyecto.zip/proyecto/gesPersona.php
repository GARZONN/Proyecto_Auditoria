<?php

session_start(); // Continua la sesión existente 

require 'conexion.php'; // Conexión a la base de datos

// Verifica la sesión, si el usuario está autenticado si no redirige a login
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Inicializa las variables para los mensajes
$mensaje = '';
$tipo_mensaje = '';
$habilitar_formulario = false;
$usuario_encontrado = false;
$errores = [];

// Variables para los datos del formulario que se van a editar
$nombres = $apellidos = $correo = $password = $confirmar_password = $usuario = $rol = $tipo_doc = $num_doc = $telefono = $direccion = $genero = '';

// Procesamiento de formulario manual y se envia por metodo POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Acción para buscar usuario
    if (isset($_POST['accion'])) {
        if ($_POST['accion'] == 'BUSCAR' && isset($_POST['buscar_usuario']) && !empty($_POST['buscar_usuario'])) {
            $buscar = trim($_POST['buscar_usuario']);

            // Se hace la consulta a la base de datos para buscar el usuario con una consulta parametrizada
            $query_buscar = "SELECT * FROM usuarios WHERE usuario = $1 AND rol IN ('digitador', 'paciente','doctor') LIMIT 1";
            $result_buscar = pg_query_params($conn, $query_buscar, [$buscar]);

            // Si se encuentra el usuario, se asignan los valores a las variables
            if ($usuario_encontrado = pg_fetch_assoc($result_buscar)) {
                $nombres   = $usuario_encontrado['nombres'];
                $apellidos = $usuario_encontrado['apellidos'];
                $correo    = $usuario_encontrado['correo'];
                $genero    = $usuario_encontrado['genero'];
                $password  = $usuario_encontrado['password'];
                $usuario   = $usuario_encontrado['usuario'];
                $rol       = $usuario_encontrado['rol'];
                $tipo_doc  = $usuario_encontrado['tipo_doc'];
                $num_doc   = $usuario_encontrado['num_doc'];
                $telefono  = $usuario_encontrado['telefono'];
                $direccion = $usuario_encontrado['direccion'];
                $habilitar_formulario = true;
            } else {
                $mensaje = "Usuario no encontrado.";
                $tipo_mensaje = "error";
            }
        }

        // Acción para actualizar
        elseif ($_POST['accion'] == 'ACTUALIZAR') {

            // Captura de datos del formulario y si no existe se asigna un valor por defecto
            if (isset($_POST['usuario_original'])) {
                $usuario_original = $_POST['usuario_original'];
            } else {
                $usuario_original = '';
            }

            if (isset($_POST['nombres'])) {
                $nombres = $_POST['nombres'];
            } else {
                $nombres = '';
            }

            if (isset($_POST['apellidos'])) {
                $apellidos = $_POST['apellidos'];
            } else {
                $apellidos = '';
            }

            if (isset($_POST['correo'])) {
                $correo = $_POST['correo'];
            } else {
                $correo = '';
            }

            if (isset($_POST['genero'])) {
                $genero = $_POST['genero'];
            } else {
                $genero = '';
            }

            if (isset($_POST['password'])) {
                $password = $_POST['password'];
            } else {
                $password = '';
            }

            if (isset($_POST['confirmar_password'])) {
                $confirmar_password = $_POST['confirmar_password'];
            } else {
                $confirmar_password = '';
            }

            if (isset($_POST['usuario'])) {
                $usuario = $_POST['usuario'];
            } else {
                $usuario = '';
            }

            if (isset($_POST['rol'])) {
                $rol = $_POST['rol'];
            } else {
                $rol = '';
            }

            if (isset($_POST['tipo_doc'])) {
                $tipo_doc = $_POST['tipo_doc'];
            } else {
                $tipo_doc = '';
            }

            if (isset($_POST['num_doc'])) {
                $num_doc = $_POST['num_doc'];
            } else {
                $num_doc = '';
            }

            if (isset($_POST['telefono'])) {
                $telefono = $_POST['telefono'];
            } else {
                $telefono = '';
            }

            if (isset($_POST['direccion'])) {
                $direccion = $_POST['direccion'];
            } else {
                $direccion = '';
            }

            // Validación de formato para cada campo del registro, rechazando entradas mal formateadas o inválidas
            if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]{2,50}$/', $nombres)) {
                $errores[] = "Nombre inválido.";
            }
            if (!preg_match('/^[A-Za-zÁÉÍÓÚáéíóúÑñ\s]{2,50}$/', $apellidos)) {
                $errores[] = "Apellido inválido.";
            }
            if (!in_array($genero, ['masculino', 'femenino'])) {
                $errores[] = "Género inválido.";
            }
            if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
                $errores[] = "Correo inválido.";
            }
            if (strlen($password) < 12 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/\d/', $password) || !preg_match('/[\W_]/', $password)) {
                $errores[] = "Contraseña insegura.";
            }
            if ($password !== $confirmar_password) {
                $errores[] = "Las contraseñas no coinciden.";
            }
            if (!preg_match('/^[A-Za-z0-9]{4,10}$/', $usuario)) {
                $errores[] = "Usuario inválido.";
            }
            if (!preg_match('/^\d{6,15}$/', $num_doc)) {
                $errores[] = "Número de documento inválido.";
            }
            if (!preg_match('/^\d{10}$/', $telefono)) {
                $errores[] = "Teléfono inválido.";
            }
            if (strlen($direccion) < 5 || strlen($direccion) > 20) {
                $errores[] = "Dirección inválida.";
            }

            // Si no hay errores, se prepara la consulta SQL para actualizar el ususario en la base de datos con parametros preparados
            if (empty($errores)) {
                $query_update = "UPDATE usuarios SET 
                    nombres = $1, apellidos = $2, correo = $3, genero = $4, password = $5,
                    rol = $6, tipo_doc = $7, num_doc = $8, telefono = $9, direccion = $10, usuario = $11
                    WHERE usuario = $12";
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $params_update = [
                    $nombres,
                    $apellidos,
                    $correo,
                    $genero,
                    $hashed_password,
                    $rol,
                    $tipo_doc,
                    $num_doc,
                    $telefono,
                    $direccion,
                    $usuario,
                    $usuario_original
                ];
                $result_update = pg_query_params($conn, $query_update, $params_update);

                // Verifica si la inserción fue exitosa actualizando el usuario através de su id
                if ($result_update) {
                    $query_id = "SELECT id FROM usuarios WHERE usuario = $1 LIMIT 1";
                    $res_id = pg_query_params($conn, $query_id, [$usuario]);
                    if ($res_id) {
                        $datos_id = pg_fetch_assoc($res_id);
                        if (isset($datos_id['id'])) {
                            $id_usuario_actualizado = $datos_id['id'];

                            // Propagar el cambio de usuario responsable en la tabla inventario
                            $usuario_responsable = $nombres . ' ' . $apellidos;
                            $query_propagar = "UPDATE inventario SET usuario_responsable = $1, rol_responsable = $2 WHERE id_usuario = $3";
                            $params_propagar = [$usuario_responsable, $rol, $id_usuario_actualizado];
                            pg_query_params($conn, $query_propagar, $params_propagar);
                        }
                    }
                    $mensaje = "Usuario actualizado correctamente.";
                    $tipo_mensaje = "success";
                } else {
                    $mensaje = "Error al actualizar usuario: " . pg_last_error($conn);
                    $tipo_mensaje = "error";
                }
            } else {
                $mensaje = implode("<br>", $errores);
                $tipo_mensaje = "error"; // Si hay errores, se muestran todos en conjunto
            }
        }

        // Acción para eliminar
        elseif ($_POST['accion'] == 'ELIMINAR') {

            // Verifica si el usuario original está definido antes de eliminar
            if (isset($_POST['usuario_original'])) {
                $usuario_original = $_POST['usuario_original'];
            } else {
                $usuario_original = '';
            }

            // Se hace la consulta a la base de datos para eliminar el usuario
            $query_delete = "DELETE FROM usuarios WHERE usuario = $1";
            $result_delete = pg_query_params($conn, $query_delete, [$usuario_original]);

            // Verifica si la eliminación fue exitosa
            if ($result_delete) {
                $mensaje = "Usuario eliminado correctamente.";
                $tipo_mensaje = "success";
            } else {
                $mensaje = "Error al eliminar usuario: " . pg_last_error($conn);
                $tipo_mensaje = "error";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestionar Persona</title>
    <link rel="stylesheet" href="estilos/gesPersona.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->

</head>

<body>

    <header>
        <a href="index.php">
            <img src="imágenes/volver.png" alt="Volver" class="btn-volver">
        </a>

        <!-- Mostrar mensaje de alerta si existe -->
        <?php if ($mensaje) { ?>
            <p class="alerta <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la lógica -->
        <?php } ?>
    </header>

    <div class="container">
        <div class="left-container">
            <h1>GESTIONAR PERSONA</h1>
        </div>

        <div class="right-container">

            <?php if (!$habilitar_formulario) { ?> <!-- Si no se ha enviado el formulario, muestra el campo de búsqueda -->
                <form method="POST">
                    <div class="form-row">
                        <div class="form-column">
                            <label for="buscar_usuario">BUSCAR USUARIO:</label>
                            <input type="text" name="buscar_usuario" id="buscar_usuario" placeholder="Proporcione identificador de usuario" required>
                        </div>
                        <div class="form-column">
                            <label>&nbsp;</label>
                            <input type="submit" name="accion" value="BUSCAR">
                        </div>
                    </div>
                </form>
            <?php } ?>

            <?php if ($habilitar_formulario) { ?> <!-- Muestra el formulario de edición si se encontro el usuario -->
                <form method="POST">

                    <div class="form-row">
                        <div class="form-column">
                            <label for="nombres">NOMBRE(S):</label>
                            <input type="text" name="nombres" id="nombres" required placeholder="Solo letras, acentos, ñ y espacios" value="<?php echo htmlspecialchars($nombres); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                        <div class="form-column">
                            <label for="apellidos">APELLIDOS:</label>
                            <input type="text" name="apellidos" id="apellidos" required placeholder="Solo letras, acentos, ñ y espacios" value="<?php echo htmlspecialchars($apellidos); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="genero">GÉNERO:</label>
                            <select name="genero" id="genero" required>
                                <option value="" disabled <?php if (!isset($genero)) echo 'selected'; ?>>Seleccione su género</option>
                                <option value="masculino" <?php if ($genero == 'masculino') echo 'selected'; ?>>Masculino</option>
                                <option value="femenino" <?php if ($genero == 'femenino') echo 'selected'; ?>>Femenino</option>
                            </select>
                        </div>
                        <div class="form-column">
                            <label for="correo">CORREO:</label>
                            <input type="email" name="correo" id="correo" required placeholder="Ej: nombre@dominio.com" value="<?php echo htmlspecialchars($correo); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="password">CONTRASEÑA:</label>
                            <input type="password" name="password" id="password" required
                                placeholder="Mínimo 12 mayús minús número símbolo" value="">
                        </div>
                        <div class="form-column">
                            <label for="confirmar_password">CONFIRMAR CONTRASEÑA:</label>
                            <input type="password" name="confirmar_password" id="confirmar_password" required
                                placeholder="Repetir contraseña" value="">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="usuario">USUARIO:</label>
                            <input type="text" name="usuario" id="usuario" required value="<?php echo htmlspecialchars($usuario); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                        <div class="form-column">
                            <label for="rol">ROL:</label>
                            <select name="rol" id="rol" required>
                                <option value="digitador" <?php if ($rol == 'digitador') echo 'selected'; ?>>Digitador</option>
                                <option value="paciente" <?php if ($rol == 'paciente') echo 'selected'; ?>>Paciente</option>
                                <option value="doctor" <?php if ($rol == 'doctor') echo 'selected'; ?>>Doctor</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="tipo_doc">TIPO DE DOCUMENTO:</label>
                            <select name="tipo_doc" id="tipo_doc" required>
                                <option value="CC" <?php if ($tipo_doc == 'CC') echo 'selected'; ?>>CC</option>
                                <option value="TI" <?php if ($tipo_doc == 'TI') echo 'selected'; ?>>TI</option>
                                <option value="TE" <?php if ($tipo_doc == 'TE') echo 'selected'; ?>>TE</option>
                            </select>
                        </div>
                        <div class="form-column">
                            <label for="num_doc">N° DE DOCUMENTO:</label>
                            <input type="text" name="num_doc" id="num_doc" required value="<?php echo htmlspecialchars($num_doc); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-column">
                            <label for="telefono">TELÉFONO:</label>
                            <input type="text" name="telefono" id="telefono" required value="<?php echo htmlspecialchars($telefono); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                        <div class="form-column">
                            <label for="direccion">DIRECCIÓN:</label>
                            <input type="text" name="direccion" id="direccion" required value="<?php echo htmlspecialchars($direccion); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        </div>
                    </div>

                    <div class="row-submit">
                        <input type="hidden" name="usuario_original" value="<?php echo htmlspecialchars($usuario); ?>"> <!-- Se usa htmlspecialchars para evitar inyecciones de código -->
                        <input type="submit" name="accion" value="ACTUALIZAR" onclick="return confirm('¿Está seguro de actualizar este usuario?');">
                        <input type="submit" name="accion" value="ELIMINAR" onclick="return confirm('¿Está seguro de eliminar este usuario?');">
                    </div>

                </form>
            <?php } ?>


        </div>
    </div>

</body>

</html>