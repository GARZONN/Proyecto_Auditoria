<?php

session_start(); // Continua la sesión existente 

session_destroy(); // Destruye la sesión existente, eliminando todas las variables de sesión

header("Location: login.php"); // Redirige al usuario a la página de inicio de sesión

exit(); // Termina la ejecución del script después de redirigir

?>
