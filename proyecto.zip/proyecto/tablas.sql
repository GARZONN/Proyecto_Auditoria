
CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nombres VARCHAR(50) NOT NULL,
    apellidos VARCHAR(50) NOT NULL,
    genero VARCHAR(10) NOT NULL CHECK (genero IN ('masculino', 'femenino')),
    correo VARCHAR(100) UNIQUE NOT NULL,
    password TEXT NOT NULL,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    rol VARCHAR(20) NOT NULL CHECK (rol IN ('superusuario', 'digitador', 'paciente', 'doctor')),
    tipo_doc VARCHAR(20) NOT NULL CHECK (tipo_doc IN ('CC', 'TI', 'TE')),
    num_doc VARCHAR(20) UNIQUE NOT NULL,
    telefono VARCHAR(15),
    direccion VARCHAR(255)
);


CREATE TABLE citas (
    id SERIAL PRIMARY KEY,
    id_usuario INT NOT NULL, 
    nombre_paciente VARCHAR(100) NOT NULL,
    fecha_cita DATE NOT NULL,
    hora_cita TIME NOT NULL,
    tipo_consulta VARCHAR(50) NOT NULL,
    motivo TEXT NOT NULL,
    id_doctor INT NOT NULL, 
    nombre_doctor VARCHAR(50) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (id_doctor) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE TABLE inventario (
    id_inventario SERIAL PRIMARY KEY,
    marca VARCHAR(50) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    serial VARCHAR(50) UNIQUE NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    estado VARCHAR(50) NOT NULL,
    id_usuario INT NOT NULL,
    usuario_responsable VARCHAR(50) NOT NULL,
    rol_responsable VARCHAR(20) NOT NULL,
    FOREIGN KEY (id_usuario) REFERENCES usuarios(id) ON DELETE CASCADE
);



