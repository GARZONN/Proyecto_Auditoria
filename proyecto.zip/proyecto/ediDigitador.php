<?php

session_start(); // Continua la sesión existente 

require 'conexion.php'; // Conexión a la base de datos

// Verifica la sesión, si el usuario está autenticado si no redirige a login
if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

// Inicializa las variables para los mensajes
$mensaje = '';
$tipo_mensaje = '';

// Almacena el usuario actual desde la sesión para usarlo en la consulta
$usuario_sesion = $_SESSION['usuario'];

// Consulta los datos del usuario actual onsulta con parametros preparados
$query = "SELECT nombres, apellidos, genero, correo, usuario, rol, tipo_doc, num_doc, telefono, direccion FROM usuarios WHERE usuario = $1 LIMIT 1";
$result = pg_query_params($conn, $query, array($usuario_sesion)); // Ejecuta la consulta con parámetros seguros

if ($result && pg_num_rows($result) > 0) {
    $datos = pg_fetch_assoc($result); // Extrae los datos en forma de arreglo asociativo
} else {
    $mensaje = "Error al obtener los datos del usuario.";
    $tipo_mensaje = "error";
}

// Procesamiento de formulario y se envia por metodo POST la nueva contraseña y su confirmación
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $password = $_POST['password'];
    $confirmar_password = $_POST['confirmar_password'];
    $errores = array();

    // Validación de seguridad de la contraseña rechazando entradas mal formateadas o inválidas
    if (strlen($password) < 12 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/\d/', $password) || !preg_match('/[\W_]/', $password)) {
        $errores[] = "Contraseña insegura.";
    }

    // Verifica si las contraseñas coinciden
    if ($password !== $confirmar_password) {
        $errores[] = "Las contraseñas no coinciden.";
    }

    // Si no hay errores, actualiza la contraseña en la base de datos
    if (empty($errores)) {
        $password_hash = password_hash($password, PASSWORD_DEFAULT); // Encripta la contraseña
        $query_update = "UPDATE usuarios SET password = $1 WHERE usuario = $2";
        $params = array($password_hash, $usuario_sesion);
        $result_update = pg_query_params($conn, $query_update, $params); // Ejecuta la actualización

        // Cierra la sesión inmediatamente después del cambio de contraseña redireccionando al login
        if ($result_update) {
            session_destroy(); 
            header("Location: login.php"); 
            exit(); 
        } else {
            $mensaje = "Error al actualizar la contraseña."; // Mensaje de error si la actualización falló
            $tipo_mensaje = "error";
        }
    } else {
        $mensaje = $errores[0]; 
        $tipo_mensaje = "error";
    }
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="estilos/ediDigitador.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>

<body>

    <header>
        <a href="digitador.php">
            <img src="imágenes/volver.png" alt="Volver" class="btn-volver">
        </a>

        <?php if ($mensaje) { ?>
            <p class="alerta <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la lógica -->
        <?php } ?>
    </header>

    <div class="container">
        <div class="left-container">
            <h1>EDITE SU PERFIL</h1>
        </div>

        <div class="right-container">
            <form method="POST">
                <div class="form-row">
                    <div class="form-column">
                        <label for="nombres">NOMBRE(S):</label>
                        <input type="text" id="nombres" value="<?php echo $datos['nombres']; ?>" disabled> <!-- Se muestra el nombre del usuario sin posibilidad de editarlo -->
                    </div>
                    <div class="form-column">
                        <label for="apellidos">APELLIDOS:</label>
                        <input type="text" id="apellidos" value="<?php echo $datos['apellidos']; ?>" disabled> <!-- Se muestra los apellido del usuario sin posibilidad de editarlo -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="genero">GÉNERO:</label>
                        <input type="text" id="genero" value="<?php echo $datos['genero']; ?>" disabled> <!-- Se muestra el genero del usuario sin posibilidad de editarlo -->
                    </div>
                    <div class="form-column">
                        <label for="correo">CORREO:</label>
                        <input type="email" id="correo" value="<?php echo $datos['correo']; ?>" disabled> <!-- Se muestra el correo del usuario sin posibilidad de editarlo -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="password">CONTRASEÑA:</label>
                        <input type="password" name="password" id="password" required placeholder="Mínimo 12 mayús minús número símbolo">
                    </div>
                    <div class="form-column">
                        <label for="confirmar_password">CONFIRMAR CONTRASEÑA:</label>
                        <input type="password" name="confirmar_password" id="confirmar_password" required placeholder="Repetir contraseña">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="usuario">USUARIO:</label>
                        <input type="text" id="usuario" value="<?php echo $datos['usuario']; ?>" disabled> <!-- Se muestra el usuario del usuario sin posibilidad de editarlo -->
                    </div>
                    <div class="form-column">
                        <label for="rol">ROL:</label>
                        <input type="text" id="rol" value="<?php echo $datos['rol']; ?>" disabled> <!-- Se muestra el rol del usuario sin posibilidad de editarlo -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="tipo_doc">TIPO DE DOCUMENTO:</label>
                        <input type="text" id="tipo_doc" value="<?php echo $datos['tipo_doc']; ?>" disabled> <!-- Se muestra el tipo de documento del usuario sin posibilidad de editarlo -->
                    </div>
                    <div class="form-column">
                        <label for="num_doc">N° DE DOCUMENTO:</label>
                        <input type="text" id="num_doc" value="<?php echo $datos['num_doc']; ?>" disabled> <!-- Se muestra el numero de documento del usuario sin posibilidad de editarlo -->
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-column">
                        <label for="telefono">TELÉFONO:</label>
                        <input type="text" id="telefono" value="<?php echo $datos['telefono']; ?>" disabled> <!-- Se muestra el telefono del usuario sin posibilidad de editarlo -->
                    </div>
                    <div class="form-column">
                        <label for="direccion">DIRECCIÓN:</label>
                        <input type="text" id="direccion" value="<?php echo $datos['direccion']; ?>" disabled> <!-- Se muestra la dirección del usuario sin posibilidad de editarlo -->
                    </div>
                </div>

                <div class="row-submit">
                    <input type="submit" value="ACTUALIZAR">
                </div>
            </form>
        </div>
    </div>

</body>

</html>