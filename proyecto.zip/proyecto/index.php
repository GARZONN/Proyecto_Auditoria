<?php

session_start(); // Continua la sesión existente 

// Verifica la sesión, si el usuario está autenticado si no redirige a login
if (!isset($_SESSION['usuario']) || empty($_SESSION['usuario'])) {
    header("Location: login.php");
    exit();
}

$mensaje = ''; // Inicializa la variable para los mensajes 

// Se valida si el mensaje de bienvenida ya fue mostrado en esta sesión
if (!isset($_SESSION['sesion_mostrada'])) {
    $mensaje = "Inicio de sesión exitoso";
    $_SESSION['sesion_mostrada'] = true;
}

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Principal</title>
    <link rel="stylesheet" href="estilos/index.css?v=<?php echo time(); ?>"> <!-- Se agrega un parámetro de tiempo para evitar el caché del navegador -->
</head>

<body>

    <header>
        <div class="header-contenedor">
            <a href="logout.php" class="panel-button">CERRAR SESIÓN</a>
            <?php if (!empty($mensaje)): ?>
                <div class="mensaje-error">
                    <p><?php echo htmlspecialchars($mensaje); ?></p> <!-- Muestra el ensaje de éxito o error segun lo que pase en la lógica -->
                </div>
            <?php endif; ?>
        </div>
    </header>

    <section class="titulo">
        <h2>Plataforma de Registro Inicial para Atención en Salud</h2>
    </section>

    <div class="container">
        <div class="panel-container">
            <h2>
                <?php
                // Muestra el saludo dependiendo del género 
                $genero = isset($_SESSION['genero']) ? strtolower(trim($_SESSION['genero'])) : '';
                $saludo = 'BIENVEND';

                // Verifica el género y ajusta el saludo segun el genero que se haya registrado
                if ($genero === 'femenino') {
                    $saludo .= 'A';
                } else {
                    $saludo .= 'O';
                }
                echo $saludo . ' ' . htmlspecialchars($_SESSION['usuario']); // Muestra el nombre del usuario
                ?>
            </h2>
            <div class="button-row">
                <a href="regPersona.php" class="panel-button">REGISTRAR NUEVA PERSONA</a>
                <a href="gesPersona.php" class="panel-button">GESTIONAR PERSONA</a>
            </div>
        </div>
    </div>

</body>

</html>